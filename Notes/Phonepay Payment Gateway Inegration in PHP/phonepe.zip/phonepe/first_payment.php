<?php
$finalXHeader = hash('sha256', '/pg/v1/status/' . $_POST['merchantId'] . '/' . $_POST['transactionId'] . "c7a7be6b-0a2b-4fd3-8734-3aa4ecfa1006") . '###' . "1";

$curl = curl_init();

curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://api.phonepe.com/apis/hermes/pg/v1/status/' . $_POST['merchantId'] . '/' . $_POST['transactionId'],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => false,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'GET',
    CURLOPT_HTTPHEADER => array(
        'Content-Type: application/json',
        'accept: application/json',
        'X-VERIFY: ' . $finalXHeader,
        'X-MERCHANT-ID: ' . $_POST['transactionId']
    ),
));


$response = curl_exec($curl);

curl_close($curl);

echo $response;