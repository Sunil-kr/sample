<?php

$data = array(
    'merchantId' => "M2243MHCATKVK",
    'merchantTransactionId' => date('Ymdhis'),
    'merchantUserId' => "M2243MHCATKVK",
    'amount' => 100,
    'redirectUrl' => "http://localhost/personal/phonepe/first_payment.php",
    'redirectMode' => 'POST',
    'callbackUrl' => "http://localhost/personal/phonepe/first_payment.php",
    'mobileNumber' => "8130973061",
    'paymentInstrument' =>
        array(
            'type' => 'PAY_PAGE',
        ),
);

$extraParams = array(
    'param1' => 'value1',
    'param2' => 'value2'
);

$requestPayload = array_merge($data, $extraParams);


$encode = base64_encode(json_encode($requestPayload));

$string = $encode . '/pg/v1/pay' . "c7a7be6b-0a2b-4fd3-8734-3aa4ecfa1006";
$sha256 = hash('sha256', $string);
$finalXHeader = $sha256 . '###' . "1";

$curl = curl_init();

curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://api.phonepe.com/apis/hermes/pg/v1/pay',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => false,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => json_encode(['request' => $encode]),
    CURLOPT_HTTPHEADER => array(
        'Content-Type: application/json',
        'X-VERIFY: ' . $finalXHeader
    ),
));

$result = curl_exec($curl);

echo $result;

curl_close($curl);

$response = json_decode($result);

$url = $response->data->instrumentResponse->redirectInfo->url;

header("Location: $url");